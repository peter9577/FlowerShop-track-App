﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;


namespace FlowerShopTrack.Presenter
{
    public class Gainsearch
    {
        public List<Model.Customer> GetCustomer(string lastName, string firstName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Model.Connect.CnnVal("FlowerShopDB")))
            {
                var output = connection.Query<Model.Customer>("dbo.GetLastName @LastName, @FirstName", new { LastName = lastName, FirstName = firstName }).ToList();
                return output;
            }
        }

        public List<Model.Customer> GetdetailedCustomer(string lastName, string firstName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Model.Connect.CnnVal("FlowerShopDB")))
            {
                var output = connection.Query<Model.Customer>("dbo.GetBothName @LastName, @FirstName", new { LastName = lastName, FirstName = firstName }).ToList();
                return output;
            }
        }

    }
}
