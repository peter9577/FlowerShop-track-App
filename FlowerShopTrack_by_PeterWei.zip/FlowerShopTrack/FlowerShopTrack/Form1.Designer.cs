﻿namespace FlowerShopTrack
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameTxt = new System.Windows.Forms.TextBox();
            this.lastNameTxt = new System.Windows.Forms.TextBox();
            this.addressTxt = new System.Windows.Forms.TextBox();
            this.telephoneTxt = new System.Windows.Forms.TextBox();
            this.deliverNumberTxt = new System.Windows.Forms.TextBox();
            this.deliverDateTxt = new System.Windows.Forms.TextBox();
            this.noteTxt = new System.Windows.Forms.TextBox();
            this.firstNameLbl = new System.Windows.Forms.Label();
            this.lastNameLbl = new System.Windows.Forms.Label();
            this.addressLbl = new System.Windows.Forms.Label();
            this.telephoneLbl = new System.Windows.Forms.Label();
            this.deliverNumberLbl = new System.Windows.Forms.Label();
            this.deliverDateLbl = new System.Windows.Forms.Label();
            this.noteLbl = new System.Windows.Forms.Label();
            this.dataBaseLst = new System.Windows.Forms.ListBox();
            this.titleLbl = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.searchBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.InsertBtn = new System.Windows.Forms.Button();
            this.buttonPnl = new System.Windows.Forms.Panel();
            this.allBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonPnl.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstNameTxt
            // 
            this.firstNameTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.firstNameTxt.Location = new System.Drawing.Point(293, 184);
            this.firstNameTxt.Multiline = true;
            this.firstNameTxt.Name = "firstNameTxt";
            this.firstNameTxt.Size = new System.Drawing.Size(145, 24);
            this.firstNameTxt.TabIndex = 0;
            // 
            // lastNameTxt
            // 
            this.lastNameTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lastNameTxt.Location = new System.Drawing.Point(293, 231);
            this.lastNameTxt.Multiline = true;
            this.lastNameTxt.Name = "lastNameTxt";
            this.lastNameTxt.Size = new System.Drawing.Size(145, 24);
            this.lastNameTxt.TabIndex = 1;
            // 
            // addressTxt
            // 
            this.addressTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addressTxt.Location = new System.Drawing.Point(293, 269);
            this.addressTxt.Multiline = true;
            this.addressTxt.Name = "addressTxt";
            this.addressTxt.Size = new System.Drawing.Size(286, 101);
            this.addressTxt.TabIndex = 2;
            // 
            // telephoneTxt
            // 
            this.telephoneTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.telephoneTxt.Location = new System.Drawing.Point(293, 376);
            this.telephoneTxt.Multiline = true;
            this.telephoneTxt.Name = "telephoneTxt";
            this.telephoneTxt.Size = new System.Drawing.Size(145, 24);
            this.telephoneTxt.TabIndex = 3;
            // 
            // deliverNumberTxt
            // 
            this.deliverNumberTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deliverNumberTxt.Location = new System.Drawing.Point(293, 415);
            this.deliverNumberTxt.Multiline = true;
            this.deliverNumberTxt.Name = "deliverNumberTxt";
            this.deliverNumberTxt.Size = new System.Drawing.Size(145, 24);
            this.deliverNumberTxt.TabIndex = 4;
            this.deliverNumberTxt.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // deliverDateTxt
            // 
            this.deliverDateTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deliverDateTxt.Location = new System.Drawing.Point(293, 459);
            this.deliverDateTxt.Multiline = true;
            this.deliverDateTxt.Name = "deliverDateTxt";
            this.deliverDateTxt.Size = new System.Drawing.Size(145, 24);
            this.deliverDateTxt.TabIndex = 5;
            // 
            // noteTxt
            // 
            this.noteTxt.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noteTxt.Location = new System.Drawing.Point(293, 543);
            this.noteTxt.Multiline = true;
            this.noteTxt.Name = "noteTxt";
            this.noteTxt.Size = new System.Drawing.Size(286, 202);
            this.noteTxt.TabIndex = 6;
            // 
            // firstNameLbl
            // 
            this.firstNameLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.firstNameLbl.AutoSize = true;
            this.firstNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.firstNameLbl.Location = new System.Drawing.Point(91, 184);
            this.firstNameLbl.Name = "firstNameLbl";
            this.firstNameLbl.Size = new System.Drawing.Size(101, 24);
            this.firstNameLbl.TabIndex = 7;
            this.firstNameLbl.Text = "First Name";
            // 
            // lastNameLbl
            // 
            this.lastNameLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lastNameLbl.AutoSize = true;
            this.lastNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lastNameLbl.Location = new System.Drawing.Point(91, 231);
            this.lastNameLbl.Name = "lastNameLbl";
            this.lastNameLbl.Size = new System.Drawing.Size(99, 24);
            this.lastNameLbl.TabIndex = 8;
            this.lastNameLbl.Text = "Last Name";
            // 
            // addressLbl
            // 
            this.addressLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.addressLbl.AutoSize = true;
            this.addressLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addressLbl.Location = new System.Drawing.Point(91, 269);
            this.addressLbl.Name = "addressLbl";
            this.addressLbl.Size = new System.Drawing.Size(80, 24);
            this.addressLbl.TabIndex = 9;
            this.addressLbl.Text = "Address";
            // 
            // telephoneLbl
            // 
            this.telephoneLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.telephoneLbl.AutoSize = true;
            this.telephoneLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.telephoneLbl.Location = new System.Drawing.Point(91, 376);
            this.telephoneLbl.Name = "telephoneLbl";
            this.telephoneLbl.Size = new System.Drawing.Size(103, 24);
            this.telephoneLbl.TabIndex = 10;
            this.telephoneLbl.Text = "Telephone";
            // 
            // deliverNumberLbl
            // 
            this.deliverNumberLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deliverNumberLbl.AutoSize = true;
            this.deliverNumberLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.deliverNumberLbl.Location = new System.Drawing.Point(91, 415);
            this.deliverNumberLbl.Name = "deliverNumberLbl";
            this.deliverNumberLbl.Size = new System.Drawing.Size(148, 24);
            this.deliverNumberLbl.TabIndex = 11;
            this.deliverNumberLbl.Text = "Delivery Amount";
            // 
            // deliverDateLbl
            // 
            this.deliverDateLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.deliverDateLbl.AutoSize = true;
            this.deliverDateLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.deliverDateLbl.Location = new System.Drawing.Point(91, 459);
            this.deliverDateLbl.Name = "deliverDateLbl";
            this.deliverDateLbl.Size = new System.Drawing.Size(120, 24);
            this.deliverDateLbl.TabIndex = 12;
            this.deliverDateLbl.Text = "Delivery Date";
            // 
            // noteLbl
            // 
            this.noteLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.noteLbl.AutoSize = true;
            this.noteLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.noteLbl.Location = new System.Drawing.Point(91, 543);
            this.noteLbl.Name = "noteLbl";
            this.noteLbl.Size = new System.Drawing.Size(50, 24);
            this.noteLbl.TabIndex = 13;
            this.noteLbl.Text = "Note";
            // 
            // dataBaseLst
            // 
            this.dataBaseLst.AllowDrop = true;
            this.dataBaseLst.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataBaseLst.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataBaseLst.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataBaseLst.FormattingEnabled = true;
            this.dataBaseLst.HorizontalScrollbar = true;
            this.dataBaseLst.ItemHeight = 21;
            this.dataBaseLst.Location = new System.Drawing.Point(611, 0);
            this.dataBaseLst.Name = "dataBaseLst";
            this.dataBaseLst.Size = new System.Drawing.Size(532, 829);
            this.dataBaseLst.TabIndex = 14;
            this.dataBaseLst.SelectedIndexChanged += new System.EventHandler(this.dataBaseLst_SelectedIndexChanged);
            // 
            // titleLbl
            // 
            this.titleLbl.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.titleLbl.AutoSize = true;
            this.titleLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLbl.ForeColor = System.Drawing.SystemColors.Highlight;
            this.titleLbl.Location = new System.Drawing.Point(166, 48);
            this.titleLbl.Name = "titleLbl";
            this.titleLbl.Size = new System.Drawing.Size(252, 29);
            this.titleLbl.TabIndex = 18;
            this.titleLbl.Text = "Marry\'s Flower Shop";
            this.titleLbl.Click += new System.EventHandler(this.titleLbl_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.AutoSize = true;
            this.exitBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.exitBtn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.exitBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.exitBtn.FlatAppearance.BorderSize = 0;
            this.exitBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.Location = new System.Drawing.Point(0, 752);
            this.exitBtn.Margin = new System.Windows.Forms.Padding(10);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(142, 77);
            this.exitBtn.TabIndex = 20;
            this.exitBtn.Text = "&Exit";
            this.exitBtn.UseVisualStyleBackColor = false;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.searchBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.searchBtn.FlatAppearance.BorderSize = 0;
            this.searchBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBtn.Location = new System.Drawing.Point(0, 154);
            this.searchBtn.Margin = new System.Windows.Forms.Padding(10);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(142, 77);
            this.searchBtn.TabIndex = 17;
            this.searchBtn.Text = "&Search";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.clearBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.clearBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.clearBtn.FlatAppearance.BorderSize = 0;
            this.clearBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearBtn.Location = new System.Drawing.Point(0, 77);
            this.clearBtn.Margin = new System.Windows.Forms.Padding(10);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(142, 77);
            this.clearBtn.TabIndex = 19;
            this.clearBtn.Text = "&Clear";
            this.clearBtn.UseVisualStyleBackColor = false;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // InsertBtn
            // 
            this.InsertBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.InsertBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.InsertBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.InsertBtn.FlatAppearance.BorderSize = 0;
            this.InsertBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertBtn.Location = new System.Drawing.Point(0, 0);
            this.InsertBtn.Margin = new System.Windows.Forms.Padding(10);
            this.InsertBtn.Name = "InsertBtn";
            this.InsertBtn.Size = new System.Drawing.Size(142, 77);
            this.InsertBtn.TabIndex = 15;
            this.InsertBtn.Text = "&Insert";
            this.InsertBtn.UseVisualStyleBackColor = false;
            this.InsertBtn.Click += new System.EventHandler(this.InsertBtn_Click);
            // 
            // buttonPnl
            // 
            this.buttonPnl.BackColor = System.Drawing.Color.Aqua;
            this.buttonPnl.Controls.Add(this.allBtn);
            this.buttonPnl.Controls.Add(this.exitBtn);
            this.buttonPnl.Controls.Add(this.searchBtn);
            this.buttonPnl.Controls.Add(this.clearBtn);
            this.buttonPnl.Controls.Add(this.InsertBtn);
            this.buttonPnl.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonPnl.Location = new System.Drawing.Point(0, 0);
            this.buttonPnl.Name = "buttonPnl";
            this.buttonPnl.Size = new System.Drawing.Size(142, 829);
            this.buttonPnl.TabIndex = 20;
            // 
            // allBtn
            // 
            this.allBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.allBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.allBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.allBtn.FlatAppearance.BorderSize = 0;
            this.allBtn.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.allBtn.Location = new System.Drawing.Point(0, 231);
            this.allBtn.Margin = new System.Windows.Forms.Padding(10);
            this.allBtn.Name = "allBtn";
            this.allBtn.Size = new System.Drawing.Size(142, 77);
            this.allBtn.TabIndex = 21;
            this.allBtn.Text = "&All";
            this.allBtn.UseVisualStyleBackColor = false;
            this.allBtn.Click += new System.EventHandler(this.allBtn_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.dataBaseLst);
            this.panel1.Controls.Add(this.firstNameTxt);
            this.panel1.Controls.Add(this.lastNameTxt);
            this.panel1.Controls.Add(this.lastNameLbl);
            this.panel1.Controls.Add(this.addressLbl);
            this.panel1.Controls.Add(this.addressTxt);
            this.panel1.Controls.Add(this.telephoneLbl);
            this.panel1.Controls.Add(this.deliverNumberLbl);
            this.panel1.Controls.Add(this.telephoneTxt);
            this.panel1.Controls.Add(this.deliverDateLbl);
            this.panel1.Controls.Add(this.noteLbl);
            this.panel1.Controls.Add(this.deliverNumberTxt);
            this.panel1.Controls.Add(this.firstNameLbl);
            this.panel1.Controls.Add(this.titleLbl);
            this.panel1.Controls.Add(this.deliverDateTxt);
            this.panel1.Controls.Add(this.noteTxt);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(142, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1143, 829);
            this.panel1.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1285, 829);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonPnl);
            this.Name = "Form1";
            this.Text = "FlowerShop Tracking";
            this.buttonPnl.ResumeLayout(false);
            this.buttonPnl.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox firstNameTxt;
        private System.Windows.Forms.TextBox lastNameTxt;
        private System.Windows.Forms.TextBox addressTxt;
        private System.Windows.Forms.TextBox telephoneTxt;
        private System.Windows.Forms.TextBox deliverNumberTxt;
        private System.Windows.Forms.TextBox deliverDateTxt;
        private System.Windows.Forms.TextBox noteTxt;
        private System.Windows.Forms.Label firstNameLbl;
        private System.Windows.Forms.Label lastNameLbl;
        private System.Windows.Forms.Label addressLbl;
        private System.Windows.Forms.Label telephoneLbl;
        private System.Windows.Forms.Label deliverNumberLbl;
        private System.Windows.Forms.Label deliverDateLbl;
        private System.Windows.Forms.Label noteLbl;
        private System.Windows.Forms.ListBox dataBaseLst;
        private System.Windows.Forms.Label titleLbl;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button InsertBtn;
        private System.Windows.Forms.Panel buttonPnl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button allBtn;
    }
}

