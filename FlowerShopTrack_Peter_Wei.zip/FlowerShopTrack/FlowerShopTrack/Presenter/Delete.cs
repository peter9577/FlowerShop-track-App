﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;
using System.Data.SqlClient;

namespace FlowerShopTrack.Presenter
{
    public class Delete
    {

        public void DeleteCustomer(string firstName, string lastName)
        {


            try
            {

                using (SqlConnection connection = new SqlConnection(Model.Connect.CnnVal("FlowerShopDB")))
                {
                    SqlCommand cmd = new SqlCommand("dbo.Delete", connection);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = firstName;
                    cmd.Parameters.Add("@LastName", SqlDbType.NVarChar).Value = lastName;
                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
            }


            catch(Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }









        }

            
        }
    
    
}
