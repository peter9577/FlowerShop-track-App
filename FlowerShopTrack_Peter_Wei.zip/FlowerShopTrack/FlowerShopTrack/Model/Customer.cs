﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;
namespace FlowerShopTrack.Model
{
    public class Customer
    {
        //creating categories and match sql
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string address { get; set; }
        public string telephone { get; set; }
        public Int32 deliverNumber { get; set; }
        public string deliverDate { get; set; }
        public string note { get; set; }

        public string FullInfo
        {

            get
            {
                //display format
                return $"{firstName} {lastName}, {address}, {telephone}, {deliverNumber} Lillies, On: {deliverDate}, Note:{note}";
            }

        }
    }
}
