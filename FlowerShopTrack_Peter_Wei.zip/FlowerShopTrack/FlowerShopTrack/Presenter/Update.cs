﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;
using System.Data.SqlClient;

namespace FlowerShopTrack.Presenter
{
    public class Update
    {
        public void UpdateCustomer(string firstName, string lastName, string address, string telephone, int deliverNumber, string deliverDate, string note)
        {

            try
            {

                using (SqlConnection connection = new SqlConnection(Model.Connect.CnnVal("FlowerShopDB")))
                {
                    SqlCommand cmd = new SqlCommand("dbo.UpDate", connection);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = firstName;
                    cmd.Parameters.Add("@LastName", SqlDbType.NVarChar).Value = lastName;
                    cmd.Parameters.Add("@Address", SqlDbType.NVarChar).Value = address;
                    cmd.Parameters.Add("@Telephone", SqlDbType.NVarChar).Value = telephone;
                    cmd.Parameters.Add("@DeliverNumber", SqlDbType.Int).Value = deliverNumber;
                    cmd.Parameters.Add("@DeliverDate", SqlDbType.NVarChar).Value = deliverDate;
                    cmd.Parameters.Add("@Note", SqlDbType.NVarChar).Value = note;

                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
            }


          catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }




        }
        
    }
}
