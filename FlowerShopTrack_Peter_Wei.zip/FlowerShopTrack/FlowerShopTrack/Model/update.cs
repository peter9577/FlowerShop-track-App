﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;

namespace FlowerShopTrack.Model
{
    public class update
    {
        List<Model.Customer> Person = new List<Model.Customer>();

        public void updateCustomer(string firstName, string lastName, string address, string telephone, string deliverNumber, string deliverDate, string note)
        {
            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName) || string.IsNullOrWhiteSpace(address) || string.IsNullOrWhiteSpace(telephone) || string.IsNullOrWhiteSpace(deliverNumber) || string.IsNullOrWhiteSpace(deliverDate))
            {
                MessageBox.Show("Please all the fields, Note can be empty");

            }
            else if (telephone.All(char.IsDigit) == false || deliverNumber.All(char.IsDigit) == false)
            {
                MessageBox.Show("Telephone and Deliver Amount must be numbers");
            }
            else if (telephone.Length != 10)
            {
                MessageBox.Show("Invalid telephone number");
            }
            else
            {

                Presenter.Update db = new Presenter.Update();
                //call insert method from DataAccrss class
                db.UpdateCustomer(firstName, lastName, address, telephone, Int32.Parse(deliverNumber), deliverDate, note);
               
            }
        }

    }
}
