﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;

namespace FlowerShopTrack
{
    public partial class Form1 : Form
    {
        //Creating Objects refer to classes
        List<Model.Customer> Person = new List<Model.Customer>();
        Model.Insert Insert = new Model.Insert();

        private void update()
        {
            //Passing the customer data into Object<Person>
            //update list box
            dataBaseLst.DataSource = Person;
            dataBaseLst.DisplayMember = "FullInfo";

        }
        public void textClear()
        {
            //clear method that clears all the txt box
            firstNameTxt.Clear();
            lastNameTxt.Clear();
            addressTxt.Clear();
            telephoneTxt.Clear();
            deliverNumberTxt.Clear();
            deliverDateTxt.Clear();
            noteTxt.Clear();

        }
        private void ClearListBox()
        {
            //clear list box method
            dataBaseLst.DataSource = null;
            dataBaseLst.Items.Clear();

        }

        public Form1()
        {
            InitializeComponent();

            update();
         }

   
        private void textBox5_TextChanged(object sender, EventArgs e){}

        private void searchBtn_Click(object sender, EventArgs e)
        {
            //control the txt box field to not be empty for search
            if (string.IsNullOrWhiteSpace(firstNameTxt.Text) && string.IsNullOrWhiteSpace(lastNameTxt.Text))
            {
                MessageBox.Show("Please enter a Customers' last name or first name to search");

            }
            else if(string.IsNullOrWhiteSpace(firstNameTxt.Text) != true && string.IsNullOrWhiteSpace(lastNameTxt.Text) != true)
            {
                Presenter.Gainsearch db = new Presenter.Gainsearch();
                //call search method from DataAccess method
                Person = db.GetdetailedCustomer(lastNameTxt.Text, firstNameTxt.Text);
                update();
            }else
            {
                Presenter.Gainsearch db = new Presenter.Gainsearch();
                //call search method from DataAccess method
                Person = db.GetCustomer(lastNameTxt.Text, firstNameTxt.Text);
                update();
            }
            
        }

        private void InsertBtn_Click(object sender, EventArgs e)
        {
            Insert.insertCustomer(firstNameTxt.Text, lastNameTxt.Text, addressTxt.Text, telephoneTxt.Text, deliverNumberTxt.Text, deliverDateTxt.Text, noteTxt.Text);
            textClear(); 
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            textClear();
            ClearListBox();   
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void titleLbl_Click(object sender, EventArgs e){}

        private void dataBaseLst_SelectedIndexChanged(object sender, EventArgs e){}

        private void allBtn_Click(object sender, EventArgs e)
        {
             //displaying all the data from the database
            Presenter.AllCustomer db = new Presenter.AllCustomer();
            Person = db.selectAll();
            update();
        }

        private void orderBtn_Click(object sender, EventArgs e)
        {

        }
    }
}
