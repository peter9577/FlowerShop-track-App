﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;

namespace FlowerShopTrack.Presenter
{
    public class InsertCustomerInfo
    {
       
        public void InsertCustomer(string firstName, string lastName, string address, string telephone, int deliverNumber, string deliverDate, string note)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Model.Connect.CnnVal("FlowerShopDB")))
            {
                Model.Customer Customer = new Model.Customer { firstName = firstName, lastName = lastName, address = address, telephone = telephone, deliverNumber = deliverNumber, deliverDate = deliverDate, note = note };
                connection.Execute("dbo.InsertCustomer @FirstName, @LastName,@Address,@telephone,@DeliverNumber, @DeliverDate,@Note", Customer);
            }
        }
    }
}
