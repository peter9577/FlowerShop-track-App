﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FlowerShopTrack.Model;
using Dapper;


namespace FlowerShopTrack.Model
{
    public class DeleteCustomer
    {
        

        public void Deletecustomer(string firstName, string lastName)
        {

            if (string.IsNullOrWhiteSpace(firstName) || string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Please enter Customers' last name and first name to Delete");

            }
            else if (string.IsNullOrWhiteSpace(firstName) && string.IsNullOrWhiteSpace(lastName))
            {
                MessageBox.Show("Please enter Customers' last name and first name to Delete");
            }
            else
            {
                Presenter.Delete Delete = new Presenter.Delete();
                Delete.DeleteCustomer(firstName, lastName);

            }

        }
    }
}
